**To delete a security configuration in the current region**

- Command::
 
    aws emr delete-security-configuration --name MySecurityConfig

- Output::

    None
