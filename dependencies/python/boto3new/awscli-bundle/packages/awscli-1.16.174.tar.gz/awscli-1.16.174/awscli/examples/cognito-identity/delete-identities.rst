**To delete identity pool**

This example deletes an identity ppol.

Command::

  aws cognito-identity delete-identity-pool --identity-ids-to-delete "us-west-2:11111111-1111-1111-1111-111111111111"

Output::

  {
    "UnprocessedIdentityIds": []
  }
